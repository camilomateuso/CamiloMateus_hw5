#include <stdio.h>
#include <stdlib.h>
#include <math.h>

float likehood(float tiempo);
float likehood1(float tiempo);
int main(void){


  int L =20000;  
  like = malloc (sizeof(float) * 20000);
  like2 = malloc (sizeof(float) * 20000);
  predadores= ;
  presas = ;
  alfa = malloc (sizeof(float) * 20000);
  beta = malloc (sizeof(float) * 20000); 
  gamma = malloc (sizeof(float) * 20000);
  dirac = malloc (sizeof(float) * 20000); 
  tiempos = malloc (sizeof(float) * 96);
  deltapresas = malloc (sizeof(float) * 96);
  deltapredadores = malloc (sizeof(float) * 96);
  deltapresasrand = malloc (sizeof(float) * 96);
  deltapredadoresrand = malloc (sizeof(float) * 96);
  int i =1;
  int k = 0;
  
  	srand((unsigned) time(&t));

	alfa[0] = rand(20);
	beta[0] = rand(20);
	gamma[0] = rand(20);
	dirac[0] = rand(20);
	while(k<95){
     	deltapresas0[k] = (presas[k+1]-presas[k])/(tiempo[k+1]-tiempo[k]);
	deltapredadores0[k] = (predadores[k+1]-predadores[k])/(tiempo[k+1]-tiempo[k]);
	k = k+1;
 	}
	
  while(i<L){
    
     alfarand = alfa[i-1] + rand(100)/10.0 - rand(10)/10.0 ;
     betarand = beta[i-1] + rand(100)/10.0 - rand(100)/10.0;
     gammarand = gamma[i-1] + rand(100)/10.0 - rand(10)/10.0; 
     diracrand = delta[i-1] + rand(100)/10.0 - rand(100)/10.0;
     k = 0;
     while(k<96){
     deltapresasrand[k] = presas[k]*(alfarand - betarand*predadores[k]);
     deltapredadoresrand[k] = -predadores[k]*(gammarand - diracrand*presas[k]);
	k = k+1;
 	}
	k=0;
     while(k<96){
     deltapresas[k] = presas[k]*(alfa[i-1] - beta[i-1]*predadores[k])
     deltapredadores[k] = -predadores[k]*(gamma[i-1] - dirac[i-1]*presas[k])
	k = k+1;
 	}
     presaslhood = likelihood(deltapresas);
     presaslhoodrand = likelihood(deltapresasrand);
     predadoreslhood = likelihood2(deltapredadores);
     predadoreslhoodrand = likelihood2(deltapredadoresrand);

     ratio = presaslhoodrand/presaslhood;
     ratio2 = predadoreslhoodrand/predadoreslhood;
     if(ratio>= 1.0){
	alfa[i] = alfarand;
	beta[i] = betarand;
	like[i] = presaslhoodrand;
	}
     else{

	if(rand()<=ratio){
	alfa[i] = alfarand;
	beta[i] = betarand;
	like[i] = presaslhoodrand;
	}
	else{
	alfa[i] = alfa[i-1];
	beta[i] = beta[i-1];
	like[i] = presaslhood;
	}
	
    if(ratio2>= 1.0){
	gamma[i] = gammarand;
	dirac[i] = diracrand;
	like[i] = presaslhoodrand
	}
     else{

	if(rand()<=ratio2){
	gamma[i] = gammarand;
	dirac[i] = diracrand;
	like[i] = presaslhoodrand;
	}
	else{
	gamma[i] = gamma[i-1];
	dirac[i] = dirac[i-1];
	like[i] = presaslhood;
	}
     
    i = i+1;
  }
  
  
float likelihood(float delta){
  
  float suma = 0;
  while(j<96){
	suma += pow(delta[k]-deltapresas0[k],2);
  }
  float chisq = (1.0/2.0)suma;
  return exp(-chisq);
}
float likelihood2(float delta){
  
  float suma = 0;
  while(j<96){
	suma += pow(delta[k]-deltapredadores0[k],2);
  }
  float chisq = (1.0/2.0)suma;
  return exp(-chisq);
}
 

   for(i=0;i<L;i++){
      for(k=0;k<L;k++){

        
        printf("%f %f\n",alfa[i],beta[i],gamma[i],dirac[i]);
         }
         }
     



}
